import { Component, Input, OnInit } from '@angular/core';
import { CadastroCCL } from '../../../../../models/consultas-internas/ccl/cadastro-ccl';
import { ConsultasInternasService } from '../../../../../services/proposta/consultas-internas.service';

@Component({
    selector: 'consultas-internas-cadastro-ccl',
    templateUrl: './consultas-internas-cadastro-ccl.component.html',
    providers: [ ConsultasInternasService ]
})

export class ConsultasInternasCadastroCCLComponent implements OnInit{

    @Input() idProposta: string;
    // @Input() cadastroCCL: CadastroCCL;
    cadastroCCL = {} as CadastroCCL;
    mensagem: string;
    exibirModal: boolean = false;
    loading: boolean;

    constructor(private consultasInternasService: ConsultasInternasService) {}

    ngOnInit(): void {
        this.getInformacoesCCL();
    }

    private getInformacoesCCL(): any {
        this.loading = true;
        this.consultasInternasService.getInformacoesCcl(this.idProposta).subscribe(
            data => {
                this.loading = false;
                if (data != null){
                    this.cadastroCCL = data;
                }
            },
            error => {
                this.loading = false;
                this.exibirModal = true;
                this.mensagem = "Falha ao obter informações do CCL";
            }
        )
    }
}