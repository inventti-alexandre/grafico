export class CCLInspetoria {
    identificacao:string;
    tipoCliente:string;
    dataConsulta:Date;
    consulta:string;
    restricao:string;
    inspetoria:string;
}