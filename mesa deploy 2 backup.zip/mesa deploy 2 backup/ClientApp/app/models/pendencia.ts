export class Pendencia {
    proposta: string;
    tipo: boolean;
    id: number;
    compromisso: number;
}