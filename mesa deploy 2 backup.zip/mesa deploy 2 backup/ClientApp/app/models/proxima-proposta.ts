export class ProximaProposta {
    idProposta: string;
}