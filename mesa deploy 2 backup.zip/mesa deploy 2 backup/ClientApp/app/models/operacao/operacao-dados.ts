export class OperacaoDados {       
    anoFabricacao: number;
    anoModelo: number;
    marca: string;
    modelo: string;
    placa: string;
    revenda: string;
    taxi: boolean;
    versao: string;
    quilometros: string;
    produto: string;
    fluxo: string;
    canal: string;
    classificacao: string;
    digitador: string;
    isencaoFiscal: boolean;
    isencaoTC: boolean;
    operador: string;
    operadorTelefone: string;
    condicao: string;
}