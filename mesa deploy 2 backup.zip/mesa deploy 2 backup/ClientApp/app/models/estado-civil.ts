export class EstadoCivil {
    idEstadoCivil: number;
    dsEstadoCivil: string;
    stCasado: string;
}