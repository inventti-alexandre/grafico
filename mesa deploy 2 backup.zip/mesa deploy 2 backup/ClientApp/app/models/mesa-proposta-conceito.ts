export class MesaPropostaConceito {
    conceito: string;
    score: string;
    perdaEsperada: number;
}