export class MesaPropostaAlerta {
    alerta: number;
    resolvido: number;
    restante: number;
}