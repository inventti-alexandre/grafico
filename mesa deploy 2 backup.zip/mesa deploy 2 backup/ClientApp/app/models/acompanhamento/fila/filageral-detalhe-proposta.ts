import { FilaGeralDetalhe } from './filageral-detalhe';

export class FilaGeralDetalheProposta {
    bloquearAcoesNaDecisaoDaFicha: boolean;
    selecionarPropostaParaAnalise: boolean;
    listaDetalhe: FilaGeralDetalhe[];
}