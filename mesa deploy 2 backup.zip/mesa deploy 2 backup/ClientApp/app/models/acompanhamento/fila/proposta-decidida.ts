import { FilaPropostaDecidida } from "./fila-proposta-decidida";

export class PropostaDecidida{
    filaPropostaDecidida: FilaPropostaDecidida[];
    totais: number;
}