export class FilaPessoal {
    id_proposta: string;
    ds_produto: string;
    id_cliente: number;
    nm_cliente_rsoc: string;
    id_prioridade: number;
    ds_motivo: string;
    id_fila: number;
    id_pessoa: string;
    ds_tipo_motivo: string;
    fl_mensagens: boolean;
    fl_retorno: number;
    id_servico: number;
    id_catalogo: string;
    id_status_analise: string;
    tp_mesa: string;
    dt_inclusao: Date;
}