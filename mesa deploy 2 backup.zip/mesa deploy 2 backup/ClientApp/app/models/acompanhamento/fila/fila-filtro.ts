export class FilaFiltro {
    nome: string;
    cpf: string;
    proposta: string;
}