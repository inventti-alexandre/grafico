export class Comprot {
    empresa: string;
    orgao: string;
    dtMovimento: Date;
    descricao: string;
}