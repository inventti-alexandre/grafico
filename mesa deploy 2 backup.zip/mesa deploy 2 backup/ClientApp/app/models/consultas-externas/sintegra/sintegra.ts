export class Sintegra {
    empresa: string;
    atividadeEconomica: string;
    situacaoCadastral: string;
    enderecoCompleto: string;
    telefones: string;
}