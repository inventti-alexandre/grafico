export class BacenHistorico {
    dataBase: Date;
    aVencer: number;
    vencido: number;
    prejuizo: number;
    carteiraCredito: number;
    limiteCredito: number;
    total: number;
}