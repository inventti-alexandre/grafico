export class BacenModalidadeValor {
    dataBase: Date;
    Valor: string;    
}