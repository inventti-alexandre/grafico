import { BacenModalidadeValor } from "./bacen-modalidade-valor";

export class BacenEmprestimos {
    descricao: string;
    valores: BacenModalidadeValor[];
}