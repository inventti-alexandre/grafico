export class BacenFluxoParcela {
    valorAVencer: number;
    valorAVencer30d: number;
    valorAVencer31d: number;
    valorAVencer61d: number;
    valorAVencer91d: number;
    valorAVencer181d: number;
    valorAVencer360d: number;

    valorVencido: number;
    valorVencido15d: number;
    valorVencido31d: number;
    valorVencido61d: number;
    valorVencido91d: number;
    valorVencido181d: number;
    valorVencido360d: number;

    valorPrejuizo: number;
    valorPrejuizoBaixado12: number;
    valorPrejuizoBaixado48: number;
    valorPrejuizoBaixado48m: number;
}