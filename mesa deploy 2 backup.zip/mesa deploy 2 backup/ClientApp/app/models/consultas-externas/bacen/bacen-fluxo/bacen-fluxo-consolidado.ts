export class BacenFluxoConsolidado {
    modalidade: string;
    valor: number;
    fechado: number;
}