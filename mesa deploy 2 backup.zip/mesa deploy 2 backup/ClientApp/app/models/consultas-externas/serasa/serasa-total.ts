export class SerasaTotal {
    totalDividasVencidas: number;
    qtdChequesSemFundo: number;
    totalChequesSemFundoBB: number;
    totalRefin: number;
    totalPefin: number;
    participacaoFalencia: boolean;
    totalAcoes: number;
}