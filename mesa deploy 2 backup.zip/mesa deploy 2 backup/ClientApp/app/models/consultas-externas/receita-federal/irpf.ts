export class Irpf {
    anoReferencia: number;
    banco: string;
    agencia: string;
    lote: string;
    dtDisponibilidade: Date;
    situacaoResgateRestituicao: string;
}