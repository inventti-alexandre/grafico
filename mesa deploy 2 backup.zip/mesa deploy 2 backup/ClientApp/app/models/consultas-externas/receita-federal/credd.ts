export class Credd {
    dtConsulta: Date;
    status: string;
    nomeReceita: string;
}