export class CetipBem {
    marca: string;
    modelo: string;
    anoModelo: string;
    statusVeiculo: string;
    veiculoFinanciado: boolean;
    statusFinanciamento: string;
    tipoGravame: string;
    tipoAgenteFinanceiro: string;
    prazoFinSNG: number;
    prazoDecContrato: number;
}