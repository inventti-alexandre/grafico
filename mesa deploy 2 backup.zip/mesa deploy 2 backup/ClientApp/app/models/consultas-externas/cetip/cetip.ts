import { CetipFinanciamento } from "./cetip-financiamento";

export class Cetip {
    financiamentos: CetipFinanciamento[];    
}