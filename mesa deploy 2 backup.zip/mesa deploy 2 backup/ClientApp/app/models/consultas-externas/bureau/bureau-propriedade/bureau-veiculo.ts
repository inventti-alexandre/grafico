export class BureauVeiculo {
    fonte: string;
    placa: string;
    anoModelo: string;
    marca: string;
    modelo: string;
}