import { BureauImovel } from "./bureau-imovel";
import { BureauVeiculo } from "./bureau-veiculo";

export class BureauPropriedade {
    veiculos: BureauVeiculo[];
    imoveis: BureauImovel[];
}

