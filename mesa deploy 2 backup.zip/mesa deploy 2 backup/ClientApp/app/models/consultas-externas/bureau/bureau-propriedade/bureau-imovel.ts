export class BureauImovel {
    fonte: string;
    cep: string;
    endereco: string;
}