export class BureauCargo {
    origem: string;
    profissao: string;
    cargo: string;
}