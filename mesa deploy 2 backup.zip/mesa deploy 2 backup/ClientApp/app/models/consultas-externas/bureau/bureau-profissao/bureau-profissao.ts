import { BureauCargo } from "./bureau-cargo";
import { BureauEscolaridade } from "./bureau-escolaridade";

export class BureauProfissao {
    cargos: BureauCargo[];
    escolaridades: BureauEscolaridade[];
}