export class BureauEmpresa {
    fonte: string;
    cnpj: string;
    empresa: string;
    qsa: string;
}