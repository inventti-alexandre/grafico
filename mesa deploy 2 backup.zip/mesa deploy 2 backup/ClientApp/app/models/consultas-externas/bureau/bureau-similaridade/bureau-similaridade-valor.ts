export class BureauSimilaridadeValor {    
    origem: string;
    valor: string;
}