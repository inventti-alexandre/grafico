export class Rais {
    empresa: string;
    cnpj: string;
    dtAdmissao: Date;
    dtDesligamento?: Date;
}