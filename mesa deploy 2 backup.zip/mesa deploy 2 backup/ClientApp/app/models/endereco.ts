export class Endereco {
    cep: string;
    logradouro: string;
    bairro: string;
    cidade: string;
    idEstado: string;
}