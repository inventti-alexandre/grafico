export class Profissao {
    idProfissao: number;
    dsProfissao: string;
}