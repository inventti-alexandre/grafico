export class Contato {
    revendaNomeAbreviado: string;
    revendaCodigo: string;
    revendaTelefoneDdd: string;
    revendaTelefoneNumero: string;
    operadorCodigo: string;
    operadorNome: string;
    operadorTelefoneDdd: string;
    operadorTelefoneNumero: string;
    operadorFuncao: string;
    gerenteCodigo: string;
    gerenteNome: string;
    gerenteTelefoneDdd: string;
    gerenteTelefoneNumero: string;
    gerenteFuncao: string;
    regionalCodigo: string;
    regionalNome: string;
    regionalTelefoneDdd: string;
    regionalTelefoneNumero: string;
    regionalFuncao: string;
    diretorCodigo: string;
    diretorNome: string;
    diretorTelefoneDdd: string;
    diretorTelefoneNumero: string;
    diretorFuncao: string;
}