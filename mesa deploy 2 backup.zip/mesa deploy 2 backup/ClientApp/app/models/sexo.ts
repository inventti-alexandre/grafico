export class Sexo {
    idSexo: string;
    dsSexo: string;
}