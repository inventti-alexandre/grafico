export class Cargo {
    idCargo: string;
    dsCargo: string;
}