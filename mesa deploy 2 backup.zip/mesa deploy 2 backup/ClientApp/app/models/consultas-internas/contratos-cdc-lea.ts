export class ContratosCdcLea {
    emissao:Date;
    status:string;
    anoModelo: string;
    marca:string;
    modelo: string
    mediaAtraso: number;
    vlrVeiculo: number;
    vlrParcela: number;
    prazo: number;
}