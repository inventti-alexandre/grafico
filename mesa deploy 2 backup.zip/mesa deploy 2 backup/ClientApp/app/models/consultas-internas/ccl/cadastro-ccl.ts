import { ConsultaCCL } from "./consulta-ccl";

export class CadastroCCL {
    fichaAtual: ConsultaCCL;
    fichaCCL: ConsultaCCL;
}