export class ResumoCCL {
    dataCadastro: Date;
    clienteDesde: Date;
    grupoCliente: string;
}