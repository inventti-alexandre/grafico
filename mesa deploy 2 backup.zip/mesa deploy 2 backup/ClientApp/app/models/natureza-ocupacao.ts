export class NaturezaOcupacao {
    idNatOcupacao: number;
    dsNatOcupacao: string;    
}