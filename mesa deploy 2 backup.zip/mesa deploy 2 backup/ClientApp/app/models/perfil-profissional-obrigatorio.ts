export class PerfilProfissionalObrigatorio {
    empresaObrigatorio: boolean;
    enderecoObrigatorio: boolean;
    // dtAdmissaoObrigatorio: boolean;
    cnpjObrigatorio: boolean;
    rendaObrigatorio: boolean;
}