export class AlertaAviso {
    descricao: string;
    valor: string;
    tipoDado: number; 
    valorComplementar: string;   
}