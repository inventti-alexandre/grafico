export class AlertaResolvido {
    id: number;
    codCompromisso: number;
    codUsuario: string;
}