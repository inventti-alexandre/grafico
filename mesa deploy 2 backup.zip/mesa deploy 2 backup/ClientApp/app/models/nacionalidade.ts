export class Nacionalidade {
    idNacionalidade: number;
    dsNacionalidade: string;
    nacionalidadeDefault: boolean;
}