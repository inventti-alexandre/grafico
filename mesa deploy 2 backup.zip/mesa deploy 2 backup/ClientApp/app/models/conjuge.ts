export class Conjuge {
    conjugeAvalista:boolean;
    cpf: number;
    idOcupacao:number;
    nome:string;
    ocupacao:string;
    renda:number;
    rendaAdicional:number;
    rendaTotal:number;
    idUfExpedidor: string;
    celularDdd: string;
    celularNumero: string;
    dtNascimento?: Date;
    idEstadoCivil: number;
    idSexo: string;
    Sexo: string;

    conjugeAvalistaAlterado:boolean;
    cpfAlterado: boolean;
    idOcupacaoAlterado:boolean;
    nomeAlterado:boolean;
    ocupacaoAlterado:boolean;
    rendaAlterado:boolean;
    rendaAdicionalAlterado:boolean;
    rendaTotalAlterado:boolean;
    idUfExpedidorAlterado: boolean;
    celularDddAlterado: boolean;
    celularNumeroAlterado: boolean;
    dtNascimentoAlterado: boolean;
    idEstadoCivilAlterado: boolean;
    idSexoAlterado: boolean;
    SexoAlterado: boolean;
}