export class Poc {
    anoPoc: number;
    sequenciaPoc: number;
    identificacao: string;
    emitente: string;
    emissao: Date;
    situacao: string;
    valor: number;
 }