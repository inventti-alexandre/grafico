export class CapturaObservacao {
    observacao: string;
}