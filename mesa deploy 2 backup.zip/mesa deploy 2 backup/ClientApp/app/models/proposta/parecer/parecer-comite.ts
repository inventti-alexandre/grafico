export class ParecerComite{
    idProposta: string;
    codUsuario: string;
    idComite: number;
    dsTipoComite: string;
}