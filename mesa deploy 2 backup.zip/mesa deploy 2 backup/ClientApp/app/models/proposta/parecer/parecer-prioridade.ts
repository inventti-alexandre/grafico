export class ParecerPrioridade {
    idPrioridade: number;
    dsPrioridade: string;
}