export class ParecerPendencia {
    idPendencia: string;
    dsPendencia: string;
    flPagamento: boolean;
    flPendencia: number;
    idCompromisso: number;
    selIdCompromissao: number;
    selIdPendencia: number;
    selFlPendencia: number;
    obrigatorioPagamento: number;
    spareposicao: number;
 }
