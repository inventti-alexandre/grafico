import { Parecer } from "./parecer";
import { ParecerMotivo } from "./parecer-motivo";

export class ParecerRecusar extends Parecer {
    motivos: ParecerMotivo[];
}
