export class ParecerUsuario{
    idProposta: string;
    codUsuario: string;
    nomeUsuario: string;
}