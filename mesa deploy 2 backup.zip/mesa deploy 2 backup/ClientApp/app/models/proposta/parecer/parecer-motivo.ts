export class ParecerMotivo {
    idMotivo: number;
    dsMotivo: string;
}