import { Endereco } from "./endereco";

export class EnderecoCidade extends Endereco {
    numero: string;
    complemento: string;
}